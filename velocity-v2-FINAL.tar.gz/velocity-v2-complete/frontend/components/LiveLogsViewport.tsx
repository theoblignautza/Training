import React from 'react';
import { useWebSocket } from '../hooks/useWebSocket';

const LiveLogsViewport: React.FC = () => {
  const { logs } = useWebSocket();
  
  return (
    <div className="bg-slate-950 rounded-lg p-4 h-64 overflow-y-auto font-mono text-sm border border-slate-800">
      <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-800">
        <h3 className="text-white font-semibold flex items-center gap-2">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
          Live System Logs
        </h3>
        <span className="text-xs text-slate-500">{logs.length} entries</span>
      </div>
      <div className="space-y-1">
        {logs.slice(-20).reverse().map((log, idx) => (
          <div key={idx} className={`text-${getLogColor(log.type)}-400 text-xs`}>
            <span className="text-slate-600">[{new Date(log.timestamp).toLocaleTimeString()}]</span> {log.message}
          </div>
        ))}
        {logs.length === 0 && (
          <div className="text-slate-600 text-center py-8">
            No logs yet. System is ready.
          </div>
        )}
      </div>
    </div>
  );
};

function getLogColor(type: string) {
  switch(type) {
    case 'error': return 'red';
    case 'warning': return 'yellow';
    case 'success': return 'green';
    default: return 'blue';
  }
}

export default LiveLogsViewport;
