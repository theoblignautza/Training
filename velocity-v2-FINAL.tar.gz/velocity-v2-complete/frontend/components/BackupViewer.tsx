import React, { useState, useEffect } from 'react';
import { getBackups, getBackupContent, restoreConfig, deleteBackup, getDevices } from '../services/api';
import { useNotifications } from '../hooks/useNotifications';
import type { Backup, Device } from '../types';

interface BackupViewerProps {
  onClose: () => void;
}

const BackupViewer: React.FC<BackupViewerProps> = ({ onClose }) => {
  const [backups, setBackups] = useState<Backup[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [selectedBackup, setSelectedBackup] = useState<Backup | null>(null);
  const [backupContent, setBackupContent] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [restoring, setRestoring] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<number | null>(null);
  const { addNotification } = useNotifications();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [backupsData, devicesData] = await Promise.all([
        getBackups(),
        getDevices()
      ]);
      setBackups(backupsData);
      setDevices(devicesData);
    } catch (error) {
      addNotification('Failed to load backups', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleViewBackup = async (backup: Backup) => {
    try {
      const content = await getBackupContent(backup.ID);
      setBackupContent(content.content);
      setSelectedBackup(backup);
      setSelectedDevice(backup.DeviceID);
    } catch (error) {
      addNotification('Failed to load backup content', 'error');
    }
  };

  const handleRestore = async () => {
    if (!selectedBackup || !selectedDevice) {
      addNotification('Please select a device for restore', 'warning');
      return;
    }

    if (!confirm(`Are you sure you want to restore this configuration to the selected device?\n\nThis will overwrite the current configuration!`)) {
      return;
    }

    setRestoring(true);
    try {
      await restoreConfig(selectedDevice, selectedBackup.ID);
      addNotification('Configuration restored successfully', 'success');
      setSelectedBackup(null);
      setBackupContent('');
    } catch (error) {
      addNotification(error instanceof Error ? error.message : 'Restore failed', 'error');
    } finally {
      setRestoring(false);
    }
  };

  const handleDelete = async (backupId: number) => {
    if (!confirm('Are you sure you want to delete this backup? This cannot be undone.')) {
      return;
    }

    try {
      await deleteBackup(backupId);
      addNotification('Backup deleted successfully', 'success');
      setBackups(backups.filter(b => b.ID !== backupId));
      if (selectedBackup?.ID === backupId) {
        setSelectedBackup(null);
        setBackupContent('');
      }
    } catch (error) {
      addNotification('Failed to delete backup', 'error');
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 rounded-lg shadow-2xl w-full max-w-6xl max-h-[90vh] flex flex-col">
        <div className="flex justify-between items-center p-6 border-b border-slate-700">
          <h2 className="text-2xl font-bold text-white">Configuration Backups</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="flex-1 overflow-hidden flex">
          {/* Backup List */}
          <div className="w-1/3 border-r border-slate-700 overflow-y-auto p-4">
            <h3 className="text-lg font-semibold text-white mb-4">Backup Files</h3>
            {loading ? (
              <div className="text-slate-400 text-center py-8">Loading...</div>
            ) : backups.length === 0 ? (
              <div className="text-slate-500 text-center py-8">
                <p>No backups found</p>
                <p className="text-sm mt-2">Backup configurations from the Devices page</p>
              </div>
            ) : (
              <div className="space-y-2">
                {backups.map((backup) => (
                  <div
                    key={backup.ID}
                    onClick={() => handleViewBackup(backup)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      selectedBackup?.ID === backup.ID
                        ? 'border-blue-500 bg-blue-500/10'
                        : 'border-slate-700 bg-slate-800 hover:border-slate-600'
                    }`}
                  >
                    <div className="font-semibold text-white text-sm mb-1">
                      {backup.DeviceHostname || backup.Filename}
                    </div>
                    <div className="text-xs text-slate-400 space-y-1">
                      <div>{backup.DeviceIP}</div>
                      <div>{formatDate(backup.CreatedAt)}</div>
                      <div>{formatFileSize(backup.Size)}</div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(backup.ID);
                      }}
                      className="mt-2 text-xs text-red-400 hover:text-red-300"
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Backup Content */}
          <div className="flex-1 flex flex-col">
            {selectedBackup ? (
              <>
                <div className="p-4 border-b border-slate-700">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-white">{selectedBackup.Filename}</h3>
                      <p className="text-sm text-slate-400">
                        {selectedBackup.DeviceHostname} ({selectedBackup.DeviceIP}) - {formatDate(selectedBackup.CreatedAt)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="flex-1">
                      <label className="block text-sm text-slate-300 mb-2">
                        Restore to device:
                      </label>
                      <select
                        value={selectedDevice || ''}
                        onChange={(e) => setSelectedDevice(Number(e.target.value))}
                        className="w-full bg-slate-800 border border-slate-600 rounded-md py-2 px-3 text-white"
                      >
                        <option value="">Select a device...</option>
                        {devices.map((device) => (
                          <option key={device.ID} value={device.ID}>
                            {device.Hostname} ({device.IPAddress})
                          </option>
                        ))}
                      </select>
                    </div>
                    <button
                      onClick={handleRestore}
                      disabled={!selectedDevice || restoring}
                      className={`px-6 py-2 rounded-md font-medium mt-6 ${
                        !selectedDevice || restoring
                          ? 'bg-slate-600 text-slate-400 cursor-not-allowed'
                          : 'bg-green-600 hover:bg-green-700 text-white'
                      }`}
                    >
                      {restoring ? 'Restoring...' : 'Restore Config'}
                    </button>
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 bg-slate-950">
                  <pre className="text-sm text-slate-300 font-mono whitespace-pre-wrap">
                    {backupContent || 'Loading...'}
                  </pre>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-slate-500">
                <div className="text-center">
                  <svg className="w-16 h-16 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <p>Select a backup to view its contents</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BackupViewer;
