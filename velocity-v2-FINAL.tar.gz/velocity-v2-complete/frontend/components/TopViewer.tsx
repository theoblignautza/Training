import React, { useState, useEffect } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  MiniMap,
  BackgroundVariant
} from 'reactflow';
import 'reactflow/dist/style.css';
import { useWebSocket } from '../hooks/useWebSocket';

interface TopViewerProps {
  onClose: () => void;
}

const TopViewer: React.FC<TopViewerProps> = ({ onClose }) => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [scanning, setScanning] = useState(false);
  const [subnet, setSubnet] = useState('192.168.1.0/24');
  const [progress, setProgress] = useState({ current: 0, total: 0 });
  const { socket } = useWebSocket();
  
  useEffect(() => {
    if (!socket) return;
    
    socket.on('topology-complete', (data: any) => {
      const { topology } = data;
      setNodes(topology.nodes);
      setEdges(topology.edges);
      setScanning(false);
      setProgress({ current: 0, total: 0 });
    });
    
    socket.on('topology-progress', (data: any) => {
      setProgress({ current: data.progress, total: data.total });
    });
    
    return () => {
      socket.off('topology-complete');
      socket.off('topology-progress');
    };
  }, [socket]);
  
  const handleScan = async () => {
    setScanning(true);
    setNodes([]);
    setEdges([]);
    setProgress({ current: 0, total: 0 });
    
    try {
      const response = await fetch('http://localhost:8080/api/v1/topology/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subnet })
      });
      
      if (!response.ok) {
        throw new Error('Scan failed');
      }
      
      const data = await response.json();
      console.log('Scan started:', data);
    } catch (error: any) {
      console.error('Scan failed:', error);
      setScanning(false);
      alert('Scan failed: ' + error.message);
    }
  };
  
  const progressPercent = progress.total > 0 
    ? Math.round((progress.current / progress.total) * 100) 
    : 0;
  
  return (
    <div className="fixed inset-0 bg-slate-900 z-50 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-4 flex justify-between items-center shadow-lg">
        <h2 className="text-2xl font-bold text-white flex items-center gap-3">
          <span className="text-3xl">🗺️</span>
          <span>Top-Viewer - Network Topology</span>
        </h2>
        <button 
          onClick={onClose}
          className="text-slate-400 hover:text-white hover:bg-slate-700 w-10 h-10 rounded flex items-center justify-center text-2xl transition-colors"
        >
          ✕
        </button>
      </div>
      
      {/* Controls */}
      <div className="bg-slate-800 border-b border-slate-700 p-4 flex gap-4 items-center">
        <input
          type="text"
          value={subnet}
          onChange={(e) => setSubnet(e.target.value)}
          placeholder="Subnet (e.g., 192.168.1.0/24)"
          disabled={scanning}
          className="flex-1 bg-slate-700 border border-slate-600 rounded px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 disabled:opacity-50"
        />
        <button
          onClick={handleScan}
          disabled={scanning}
          className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-900 disabled:cursor-not-allowed text-white rounded font-semibold transition-colors flex items-center gap-2"
        >
          {scanning ? (
            <>
              <span className="animate-spin">⟳</span>
              <span>Scanning... {progressPercent}%</span>
            </>
          ) : (
            <>
              <span>🔍</span>
              <span>Scan Network</span>
            </>
          )}
        </button>
        <div className="text-white flex items-center gap-2 bg-slate-700 px-4 py-2 rounded">
          <span className="font-semibold">{nodes.length}</span>
          <span className="text-slate-400">devices</span>
        </div>
      </div>
      
      {/* Progress Bar */}
      {scanning && (
        <div className="bg-slate-800 border-b border-slate-700 px-4 py-2">
          <div className="flex items-center gap-3">
            <div className="flex-1 bg-slate-700 rounded-full h-2 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-blue-500 to-green-500 h-2 transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="text-slate-400 text-sm font-mono">
              {progress.current} / {progress.total}
            </span>
          </div>
        </div>
      )}
      
      {/* Topology Graph */}
      <div className="flex-1 relative bg-slate-950">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          fitView
        >
          <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="#334155" />
          <Controls className="bg-slate-800 border border-slate-700" />
          <MiniMap 
            className="bg-slate-800 border border-slate-700"
            nodeColor={(node: any) => {
              return node.style?.background as string || '#3b82f6';
            }}
          />
        </ReactFlow>
        
        {nodes.length === 0 && !scanning && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center text-slate-500">
              <div className="text-6xl mb-4">🗺️</div>
              <div className="text-xl">Enter a subnet and click "Scan Network" to begin</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TopViewer;
