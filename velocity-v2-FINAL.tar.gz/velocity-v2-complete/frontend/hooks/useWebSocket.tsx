import { useEffect, useState, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import type { LogMessage } from '../types';

const SOCKET_URL = 'http://localhost:8080';

export function useWebSocket() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const [logs, setLogs] = useState<LogMessage[]>([]);

  useEffect(() => {
    const socketInstance = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      reconnectionDelay: 1000,
      reconnection: true,
      reconnectionAttempts: 10
    });

    socketInstance.on('connect', () => {
      console.log('WebSocket connected');
      setConnected(true);
    });

    socketInstance.on('disconnect', () => {
      console.log('WebSocket disconnected');
      setConnected(false);
    });

    socketInstance.on('log', (log: LogMessage) => {
      setLogs(prev => [...prev, log].slice(-100)); // Keep last 100 logs
    });

    setSocket(socketInstance);

    return () => {
      socketInstance.close();
    };
  }, []);

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  const subscribe = useCallback((room: string) => {
    if (socket) {
      socket.emit('subscribe', room);
    }
  }, [socket]);

  const unsubscribe = useCallback((room: string) => {
    if (socket) {
      socket.emit('unsubscribe', room);
    }
  }, [socket]);

  return {
    socket,
    connected,
    connectionStatus: connected ? 'connected' : 'disconnected',
    logs,
    clearLogs,
    subscribe,
    unsubscribe
  };
}
