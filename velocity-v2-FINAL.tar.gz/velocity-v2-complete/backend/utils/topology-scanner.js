const { scanHost, parseSubnet, generateIPsInSubnet } = require('./network-scanner');

async function scanTopology(subnet, db, io, sessionId) {
  try {
    io.emit('log', {
      type: 'info',
      message: `Scanning topology for ${subnet}`,
      timestamp: new Date().toISOString()
    });
    
    const ips = generateIPsInSubnet(subnet);
    const devices = [];
    const concurrency = 50;
    
    for (let i = 0; i < ips.length; i += concurrency) {
      const batch = ips.slice(i, i + concurrency);
      const batchResults = await Promise.all(
        batch.map(ip => scanHost(ip, io))
      );
      
      const reachable = batchResults.filter(r => r.reachable);
      devices.push(...reachable);
      
      const progress = Math.min(i + concurrency, ips.length);
      io.emit('topology-progress', {
        sessionId,
        progress,
        total: ips.length,
        devicesFound: devices.length
      });
    }
    
    // Build topology structure
    const topology = buildTopologyGraph(devices, subnet);
    
    io.emit('log', {
      type: 'success',
      message: `Topology scan complete: Found ${devices.length} devices`,
      timestamp: new Date().toISOString()
    });
    
    return topology;
  } catch (error) {
    io.emit('log', {
      type: 'error',
      message: `Topology scan error: ${error.message}`,
      timestamp: new Date().toISOString()
    });
    throw error;
  }
}

function buildTopologyGraph(devices, subnet) {
  const nodes = devices.map((device, index) => ({
    id: `node-${index}`,
    type: 'device',
    position: { x: 0, y: 0 }, // Will be auto-laid out by React Flow
    data: {
      label: device.hostname,
      ip: device.ip,
      ssh: device.ssh,
      telnet: device.telnet,
      deviceType: determineDeviceType(device)
    }
  }));
  
  // Build edges based on subnet proximity (simplified)
  const edges = [];
  const subnetInfo = parseSubnet(subnet);
  
  // Connect devices in same subnet
  for (let i = 0; i < nodes.length - 1; i++) {
    edges.push({
      id: `edge-${i}`,
      source: nodes[i].id,
      target: nodes[i + 1].id,
      type: 'smoothstep',
      animated: false,
      data: {
        bandwidth: 'unknown'
      }
    });
  }
  
  return {
    nodes,
    edges,
    subnet: subnet,
    deviceCount: devices.length
  };
}

function determineDeviceType(device) {
  // Simple device type detection based on available services
  if (device.ssh && device.telnet) {
    return 'router';
  } else if (device.ssh) {
    return 'switch';
  } else if (device.telnet) {
    return 'legacy';
  }
  return 'unknown';
}

module.exports = {
  scanTopology,
  buildTopologyGraph
};
