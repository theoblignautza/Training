const { NodeSSH } = require('node-ssh');
const Telnet = require('telnet-client');
const path = require('path');
const fs = require('fs').promises;

// Ensure backups directory exists
const BACKUPS_DIR = path.join(__dirname, '..', 'backups');
fs.mkdir(BACKUPS_DIR, { recursive: true }).catch(console.error);

/**
 * Backup device configuration via SSH
 */
async function backupViaSSH(device, io) {
  const ssh = new NodeSSH();
  
  try {
    io.emit('log', {
      type: 'info',
      message: `Establishing SSH connection to ${device.ip_address}:${device.port}...`,
      timestamp: new Date().toISOString()
    });
    
    await ssh.connect({
      host: device.ip_address,
      port: device.port,
      username: device.username,
      password: device.password,
      readyTimeout: 30000,
      tryKeyboard: true
    });
    
    io.emit('log', {
      type: 'success',
      message: 'SSH connection established',
      timestamp: new Date().toISOString()
    });
    
    // Cisco-style show running-config command
    io.emit('log', {
      type: 'info',
      message: 'Executing: show running-config',
      timestamp: new Date().toISOString()
    });
    
    const result = await ssh.execCommand('show running-config');
    
    if (result.code !== 0) {
      throw new Error(`Command failed: ${result.stderr}`);
    }
    
    const config = result.stdout;
    
    // Generate filename
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `${device.hostname}_${timestamp}.cfg`;
    const filepath = path.join(BACKUPS_DIR, filename);
    
    // Save config to file
    await fs.writeFile(filepath, config, 'utf8');
    
    io.emit('log', {
      type: 'success',
      message: `Configuration saved: ${filename}`,
      timestamp: new Date().toISOString()
    });
    
    ssh.dispose();
    
    return { filename, filepath, config };
  } catch (error) {
    ssh.dispose();
    throw error;
  }
}

/**
 * Backup device configuration via Telnet
 */
async function backupViaTelnet(device, io) {
  const telnet = new Telnet();
  
  const params = {
    host: device.ip_address,
    port: device.port,
    shellPrompt: /[$#>]$/,
    timeout: 30000,
    loginPrompt: /[Uu]sername:|[Ll]ogin:/,
    passwordPrompt: /[Pp]assword:/,
    username: device.username,
    password: device.password,
    irs: '\r\n',
    ors: '\n',
    echoLines: 1
  };
  
  try {
    io.emit('log', {
      type: 'info',
      message: `Establishing Telnet connection to ${device.ip_address}:${device.port}...`,
      timestamp: new Date().toISOString()
    });
    
    await telnet.connect(params);
    
    io.emit('log', {
      type: 'success',
      message: 'Telnet connection established',
      timestamp: new Date().toISOString()
    });
    
    // Disable paging
    io.emit('log', {
      type: 'info',
      message: 'Disabling pagination...',
      timestamp: new Date().toISOString()
    });
    
    await telnet.send('terminal length 0');
    
    // Get running config
    io.emit('log', {
      type: 'info',
      message: 'Executing: show running-config',
      timestamp: new Date().toISOString()
    });
    
    const config = await telnet.send('show running-config');
    
    // Generate filename
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `${device.hostname}_${timestamp}.cfg`;
    const filepath = path.join(BACKUPS_DIR, filename);
    
    // Save config to file
    await fs.writeFile(filepath, config, 'utf8');
    
    io.emit('log', {
      type: 'success',
      message: `Configuration saved: ${filename}`,
      timestamp: new Date().toISOString()
    });
    
    await telnet.end();
    
    return { filename, filepath, config };
  } catch (error) {
    await telnet.end();
    throw error;
  }
}

/**
 * Restore device configuration via SSH
 */
async function restoreViaSSH(device, config, io) {
  const ssh = new NodeSSH();
  
  try {
    io.emit('log', {
      type: 'info',
      message: `Establishing SSH connection to ${device.ip_address}:${device.port}...`,
      timestamp: new Date().toISOString()
    });
    
    await ssh.connect({
      host: device.ip_address,
      port: device.port,
      username: device.username,
      password: device.password,
      readyTimeout: 30000,
      tryKeyboard: true
    });
    
    io.emit('log', {
      type: 'success',
      message: 'SSH connection established',
      timestamp: new Date().toISOString()
    });
    
    // Enter configuration mode
    io.emit('log', {
      type: 'info',
      message: 'Entering configuration mode...',
      timestamp: new Date().toISOString()
    });
    
    await ssh.execCommand('configure terminal');
    
    // Split config into lines and send each command
    const lines = config.split('\n').filter(line => {
      const trimmed = line.trim();
      return trimmed && 
             !trimmed.startsWith('!') && 
             !trimmed.startsWith('Building') &&
             !trimmed.startsWith('Current configuration') &&
             !trimmed.includes('version');
    });
    
    io.emit('log', {
      type: 'info',
      message: `Applying ${lines.length} configuration lines...`,
      timestamp: new Date().toISOString()
    });
    
    let output = '';
    let successCount = 0;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      if (i % 10 === 0) {
        io.emit('log', {
          type: 'info',
          message: `Progress: ${i}/${lines.length} lines applied`,
          timestamp: new Date().toISOString()
        });
      }
      
      try {
        const result = await ssh.execCommand(line);
        output += result.stdout + '\n';
        
        if (result.stderr && !result.stderr.includes('Invalid') && !result.stderr.includes('Error')) {
          output += result.stderr + '\n';
        } else if (result.stderr) {
          io.emit('log', {
            type: 'warning',
            message: `Warning on line "${line}": ${result.stderr}`,
            timestamp: new Date().toISOString()
          });
        }
        
        successCount++;
      } catch (cmdError) {
        io.emit('log', {
          type: 'warning',
          message: `Failed to apply: ${line}`,
          timestamp: new Date().toISOString()
        });
      }
    }
    
    // Exit configuration mode and save
    io.emit('log', {
      type: 'info',
      message: 'Saving configuration...',
      timestamp: new Date().toISOString()
    });
    
    await ssh.execCommand('end');
    const saveResult = await ssh.execCommand('write memory');
    output += '\n' + saveResult.stdout;
    
    io.emit('log', {
      type: 'success',
      message: `Restore completed: ${successCount}/${lines.length} lines applied`,
      timestamp: new Date().toISOString()
    });
    
    ssh.dispose();
    
    return { output, linesApplied: successCount, totalLines: lines.length };
  } catch (error) {
    ssh.dispose();
    throw error;
  }
}

/**
 * Restore device configuration via Telnet
 */
async function restoreViaTelnet(device, config, io) {
  const telnet = new Telnet();
  
  const params = {
    host: device.ip_address,
    port: device.port,
    shellPrompt: /[$#>]$/,
    timeout: 30000,
    loginPrompt: /[Uu]sername:|[Ll]ogin:/,
    passwordPrompt: /[Pp]assword:/,
    username: device.username,
    password: device.password,
    irs: '\r\n',
    ors: '\n',
    echoLines: 1
  };
  
  try {
    io.emit('log', {
      type: 'info',
      message: `Establishing Telnet connection to ${device.ip_address}:${device.port}...`,
      timestamp: new Date().toISOString()
    });
    
    await telnet.connect(params);
    
    io.emit('log', {
      type: 'success',
      message: 'Telnet connection established',
      timestamp: new Date().toISOString()
    });
    
    // Enter configuration mode
    io.emit('log', {
      type: 'info',
      message: 'Entering configuration mode...',
      timestamp: new Date().toISOString()
    });
    
    await telnet.send('configure terminal');
    
    // Split config into lines
    const lines = config.split('\n').filter(line => {
      const trimmed = line.trim();
      return trimmed && 
             !trimmed.startsWith('!') && 
             !trimmed.startsWith('Building') &&
             !trimmed.startsWith('Current configuration') &&
             !trimmed.includes('version');
    });
    
    io.emit('log', {
      type: 'info',
      message: `Applying ${lines.length} configuration lines...`,
      timestamp: new Date().toISOString()
    });
    
    let output = '';
    let successCount = 0;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      if (i % 10 === 0) {
        io.emit('log', {
          type: 'info',
          message: `Progress: ${i}/${lines.length} lines applied`,
          timestamp: new Date().toISOString()
        });
      }
      
      try {
        const result = await telnet.send(line);
        output += result + '\n';
        successCount++;
      } catch (cmdError) {
        io.emit('log', {
          type: 'warning',
          message: `Failed to apply: ${line}`,
          timestamp: new Date().toISOString()
        });
      }
    }
    
    // Exit and save
    io.emit('log', {
      type: 'info',
      message: 'Saving configuration...',
      timestamp: new Date().toISOString()
    });
    
    await telnet.send('end');
    const saveResult = await telnet.send('write memory');
    output += '\n' + saveResult;
    
    io.emit('log', {
      type: 'success',
      message: `Restore completed: ${successCount}/${lines.length} lines applied`,
      timestamp: new Date().toISOString()
    });
    
    await telnet.end();
    
    return { output, linesApplied: successCount, totalLines: lines.length };
  } catch (error) {
    await telnet.end();
    throw error;
  }
}

/**
 * Main backup function - routes to SSH or Telnet based on protocol
 */
async function backupDeviceConfig(device, io) {
  if (device.protocol === 'ssh') {
    return await backupViaSSH(device, io);
  } else if (device.protocol === 'telnet') {
    return await backupViaTelnet(device, io);
  } else {
    throw new Error(`Unsupported protocol: ${device.protocol}`);
  }
}

/**
 * Main restore function - routes to SSH or Telnet based on protocol
 */
async function restoreDeviceConfig(device, config, io) {
  if (device.protocol === 'ssh') {
    return await restoreViaSSH(device, config, io);
  } else if (device.protocol === 'telnet') {
    return await restoreViaTelnet(device, config, io);
  } else {
    throw new Error(`Unsupported protocol: ${device.protocol}`);
  }
}

module.exports = {
  backupDeviceConfig,
  restoreDeviceConfig
};
