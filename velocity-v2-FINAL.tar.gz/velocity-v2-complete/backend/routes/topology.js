const express = require('express');
const router = express.Router();
const { scanTopology } = require('../utils/topology-scanner');

// Start topology scan
router.post('/scan', async (req, res, next) => {
  const io = req.app.get('io');
  const db = req.app.get('db');
  const { subnet } = req.body;
  
  try {
    const targetSubnet = subnet || '192.168.1.0/24';
    
    // Create topology session
    const sessionStmt = db.prepare(`
      INSERT INTO topology_sessions (subnet, status)
      VALUES (?, 'running')
    `);
    
    const session = sessionStmt.run(targetSubnet);
    const sessionId = session.lastInsertRowid;
    
    io.emit('log', {
      type: 'info',
      message: `Starting topology scan: ${targetSubnet}`,
      timestamp: new Date().toISOString()
    });
    
    // Start scan (async)
    scanTopology(targetSubnet, db, io, sessionId)
      .then(topology => {
        db.prepare(`
          UPDATE topology_sessions
          SET devices_found = ?, topology_data = ?, status = 'completed', completed_at = datetime('now')
          WHERE id = ?
        `).run(topology.nodes.length, JSON.stringify(topology), sessionId);
        
        io.emit('topology-complete', {
          sessionId,
          topology,
          timestamp: new Date().toISOString()
        });
      })
      .catch(error => {
        db.prepare(`
          UPDATE topology_sessions
          SET status = 'failed', completed_at = datetime('now')
          WHERE id = ?
        `).run(sessionId);
        
        io.emit('log', {
          type: 'error',
          message: `Topology scan failed: ${error.message}`,
          timestamp: new Date().toISOString()
        });
      });
    
    res.json({
      message: 'Topology scan started',
      sessionId,
      subnet: targetSubnet
    });
  } catch (error) {
    next(error);
  }
});

// Get topology session
router.get('/session/:id', (req, res, next) => {
  try {
    const db = req.app.get('db');
    const { id } = req.params;
    
    const session = db.prepare(`
      SELECT * FROM topology_sessions WHERE id = ?
    `).get(id);
    
    if (!session) {
      return res.status(404).json({ error: true, message: 'Session not found' });
    }
    
    res.json({
      ID: session.id,
      Subnet: session.subnet,
      DevicesFound: session.devices_found,
      Topology: session.topology_data ? JSON.parse(session.topology_data) : null,
      Status: session.status,
      StartedAt: session.started_at,
      CompletedAt: session.completed_at
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
