const express = require('express');
const router = express.Router();
const { startSchedule } = require('../utils/backup-scheduler');

// Get all schedules
router.get('/', (req, res, next) => {
  try {
    const db = req.app.get('db');
    const schedules = db.prepare(`
      SELECT * FROM backup_schedules ORDER BY created_at DESC
    `).all();
    
    res.json(schedules.map(s => ({
      ID: s.id,
      Name: s.name,
      CronExpression: s.cron_expression,
      DeviceIDs: s.device_ids ? JSON.parse(s.device_ids) : null,
      Enabled: Boolean(s.enabled),
      LastRun: s.last_run,
      NextRun: s.next_run,
      CreatedAt: s.created_at
    })));
  } catch (error) {
    next(error);
  }
});

// Create schedule
router.post('/', (req, res, next) => {
  try {
    const db = req.app.get('db');
    const io = req.app.get('io');
    const { name, cronExpression, deviceIds } = req.body;
    
    if (!name || !cronExpression) {
      return res.status(400).json({
        error: true,
        message: 'Name and cron expression required'
      });
    }
    
    const stmt = db.prepare(`
      INSERT INTO backup_schedules (name, cron_expression, device_ids)
      VALUES (?, ?, ?)
    `);
    
    const result = stmt.run(
      name,
      cronExpression,
      deviceIds ? JSON.stringify(deviceIds) : null
    );
    
    const schedule = db.prepare(`
      SELECT * FROM backup_schedules WHERE id = ?
    `).get(result.lastInsertRowid);
    
    // Start the schedule
    startSchedule(schedule, db, io);
    
    io.emit('log', {
      type: 'success',
      message: `Backup schedule created: ${name}`,
      timestamp: new Date().toISOString()
    });
    
    res.status(201).json({
      ID: schedule.id,
      Name: schedule.name,
      CronExpression: schedule.cron_expression,
      Enabled: Boolean(schedule.enabled)
    });
  } catch (error) {
    next(error);
  }
});

// Delete schedule
router.delete('/:id', (req, res, next) => {
  try {
    const db = req.app.get('db');
    const { id } = req.params;
    
    db.prepare('DELETE FROM backup_schedules WHERE id = ?').run(id);
    
    res.status(204).send();
  } catch (error) {
    next(error);
  }
});

// Get backup queue status
router.get('/queue', (req, res, next) => {
  try {
    const db = req.app.get('db');
    const queue = db.prepare(`
      SELECT 
        bq.*,
        d.hostname,
        d.ip_address
      FROM backup_queue bq
      JOIN devices d ON bq.device_id = d.id
      ORDER BY bq.created_at DESC
      LIMIT 50
    `).all();
    
    res.json(queue.map(q => ({
      ID: q.id,
      DeviceID: q.device_id,
      Hostname: q.hostname,
      IPAddress: q.ip_address,
      Status: q.status,
      Progress: q.progress,
      ErrorMessage: q.error_message,
      StartedAt: q.started_at,
      CompletedAt: q.completed_at
    })));
  } catch (error) {
    next(error);
  }
});

module.exports = router;
